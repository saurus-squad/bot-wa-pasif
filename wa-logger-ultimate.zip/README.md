WA Logger Ultimate
==================
- Node.js v21+ (tested on v21.7.3)
- Start: npm install && npm start  (panel: npm start)
- Scan QR from panel (ASCII)
- Set backup group inside the group by sending: !setgroupbackup
- Logs: logs/users/, logs/groups/, logs/status/
- Media: media/users/, media/groups/, media/status/
